package com.moallemmalo.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int purple = Color.rgb(91,91,214);
    int dark = Color.rgb(31,43,104);
    int card = Color.rgb(235,234,250);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showDashboard();
    }

    TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(8,8,8,8);
        return t;
    }

    Button item(String label, String icon) {
        Button x = new Button(this);
        x.setText(icon + "\n" + label);
        x.setTextSize(15);
        x.setTextColor(Color.BLACK);
        x.setAllCaps(false);
        x.setGravity(Gravity.CENTER);
        x.setBackgroundColor(card);
        x.setPadding(8,8,8,8);
        x.setOnClickListener(v -> Toast.makeText(this, label + " — قريباً", Toast.LENGTH_SHORT).show());
        return x;
    }

    void showDashboard() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(18, 18, 18, 18);
        page.setBackgroundColor(Color.rgb(249,248,253));

        TextView title = tv("معلم ملو", 28, dark, true);
        title.setGravity(Gravity.RIGHT);
        page.addView(title, new LinearLayout.LayoutParams(-1, 55));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(20, 12, 20, 12);
        info.setBackgroundColor(Color.WHITE);
        TextView hello = tv("أهلاً بك\nالمعلم الناجح", 22, Color.BLACK, true);
        hello.setGravity(Gravity.RIGHT);
        info.addView(hello);
        page.addView(info, new LinearLayout.LayoutParams(-1, 120));

        TextView section = tv("أدوات المعلم", 20, dark, true);
        section.setGravity(Gravity.RIGHT);
        section.setPadding(0,18,0,10);
        page.addView(section);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setRowCount(5);
        grid.setUseDefaultMargins(true);

        String[][] data = {
            {"الصفوف والطلاب","👥"},
            {"الحضور","☑"},
            {"الدرجات","▥"},
            {"التقارير","▤"},
            {"الامتحانات","☷"},
            {"الجدول","▦"},
            {"الإشعارات","🔔"},
            {"الملاحظات والسلوك","✎"},
            {"الإعدادات","⚙"}
        };
        for (String[] d : data) {
            Button bt = item(d[0], d[1]);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0; lp.height = 125;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(6,6,6,6);
            grid.addView(bt, lp);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(grid);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button settings = item("الإعدادات", "⚙");
        settings.setBackgroundColor(purple);
        settings.setTextColor(Color.WHITE);
        page.addView(settings, new LinearLayout.LayoutParams(-1, 58));

        setContentView(page);
    }
}
